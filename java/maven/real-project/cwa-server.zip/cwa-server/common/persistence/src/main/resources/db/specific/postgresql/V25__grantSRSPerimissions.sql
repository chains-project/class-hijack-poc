GRANT SELECT, INSERT ON TABLE self_report_submissions TO "cwa_submission";
GRANT SELECT, DELETE ON TABLE self_report_submissions TO "cwa_distribution";
