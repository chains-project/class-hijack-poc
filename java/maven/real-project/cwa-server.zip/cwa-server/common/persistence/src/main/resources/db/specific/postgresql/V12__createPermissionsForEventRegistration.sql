GRANT INSERT ON TABLE trace_time_interval_warning TO "cwa_submission";
