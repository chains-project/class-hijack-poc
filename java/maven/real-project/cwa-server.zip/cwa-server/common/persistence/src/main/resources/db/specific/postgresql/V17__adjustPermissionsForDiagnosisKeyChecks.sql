GRANT SELECT ON TABLE diagnosis_key TO "cwa_submission";
