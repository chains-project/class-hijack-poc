package app.coronawarn.server.services.distribution.dcc;

public class FetchDccListException extends Exception {
  private static final long serialVersionUID = -6658461155713651342L;

  public FetchDccListException(String message, Throwable cause) {
    super(message, cause);
  }
}
