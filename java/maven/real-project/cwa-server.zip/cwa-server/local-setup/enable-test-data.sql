/* Test Data profile requires insert permissions on diagnois key table */
GRANT INSERT ON diagnosis_key TO cwa_distribution;
