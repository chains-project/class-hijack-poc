package org.everit.json.schema;

public enum ReadWriteContext {
    READ, WRITE
}
