package org.everit.json.schema.regexp;

public interface RegexpFactory {

    Regexp createHandler(String input);

}
