package org.everit.json.schema;

public enum PrimitiveValidationStrategy {
    STRICT, LENIENT
}
