package org.everit.json.schema.regexp;

public class RegexpMatchingFailure {

    RegexpMatchingFailure() {
    }

    @Override public boolean equals(Object obj) {
        return obj instanceof RegexpMatchingFailure;
    }
}
